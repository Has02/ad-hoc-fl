"""
Distribution of initial battery life and battery life reduction functions for devices.
For each device, we will select a random phone model and a random initial battery life.
After each communication round, we will reduce battery life based on the training time and average power consumption of the phone.

Average battery life percentage is fairly uniform between 60% and 70%
https://www.researchgate.net/publication/225256651_Understanding_Human-Smartphone_Concerns_A_Study_of_Battery_Life/figures?lo=1


TODO: Could be worth looking into how energy consumption by 5G vs 4G networks adds to decrease.
https://www.alcansystems.com/files/news/2019-12-27_5G-and-Beyond.pdf
For now, implement based on hardware consumption.

Can use the equation from the MOHAWK paper to calculate battery life reduction, caveat is it only
accounts for upload speed

https://citeseerx.ist.psu.edu/document?repid=rep1&type=pdf&doi=37cbd5bf8c460f057d30cbdd01a97d5aefe6fa92

Power can also be modeled something like section 4.4 in the batteryfl paper:
Function of baseline power, number of cores, utilization of the core, frequency of the core, and a power coefficient.

Pi = P_baseline + sum[0 to n](P_core * U_core * F_core * Y) where n is the number of cores and Y is the power coefficient.

Then just multiply Pi by training time to get the power consumption for that round of training.
"""

import numpy as np

# generate bayesian distribution of battery life, where the average battery life is between 60% and 70%
battery_life = np.random.normal(0.65, 0.05, 1000)
# battery_life = np.random.uniform(0.6, 0.7, 1000)
scaling_factor = 37.0

"""
Dictionary of phone models:
 - Name : model name (str)
    - Power consumption: average power consumption in watts (float)
    - Battery Capacity: battery capacity in watt-hours (float)

"""
phone_models = {
    "apple_iphone_15": {
        "battery_capacity": 12.98,
        "cores": 6,
        "power_coefficient": 0.1,
        "baseline_power": 0.5,
        "frequency": 2.5,
    },
    "samsung_galaxy_s22": {
        "battery_capacity": 12.21,
        "cores": 8,
        "power_coefficient": 0.1,
        "baseline_power": 0.7,
        "frequency": 1.785,
    },
    "google_pixel_7": {
        "battery_capacity": 14.37,
        "cores": 8,
        "power_coefficient": 0.1,
        "baseline_power": 0.6,
        "frequency": 2.285,
    },
}


"""
Initialize phone and battery life.
"""


def init_battery(seed=None):
    if seed is not None:
        np.random.seed(seed)
    phone = np.random.choice(list(phone_models.keys()))
    battery = np.random.choice(battery_life)
    return phone, battery


def reduce_battery(phone, battery, training_time):
    try:
        model = phone_models[phone]
    except:
        model = np.random.choice(list(phone_models.values()))
    power_consumption = (
        model["baseline_power"]
        + model["cores"] * model["power_coefficient"] * model["frequency"]
    )
    current_wh = battery * model["battery_capacity"]
    if power_consumption * (scaling_factor * (training_time / 3600)) > current_wh:
        return 0
    total = power_consumption * (scaling_factor * (training_time / 3600))
    current_wh -= total
    battery = current_wh / model["battery_capacity"]
    if battery < 0:
        battery = 0
    return battery, total


def plot_battery_life(battery_life, num_rounds, num_devices, experiment_name):
    import matplotlib.pyplot as plt

    # Pad battery_life to ensure all devices have data for all rounds
    max_rounds = num_rounds + 1
    padded_battery = [
        device_battery + [device_battery[-1]] * (max_rounds - len(device_battery))
        for device_battery in battery_life
    ]

    battery = np.array(padded_battery).reshape(num_devices, max_rounds)
    plt.plot(battery.T, alpha=0.5)
    plt.plot(battery.mean(axis=0), color="black")
    plt.xlabel("Communication Round")
    plt.ylabel("Battery Life")
    plt.title("Battery Life Reduction of {} Devices".format(num_devices))
    # save the plot
    plt.savefig("figs/" + experiment_name + "_battery.png")


"""
Implementation of auction-based energy-aware selection

We input the battery life and accuracies of the devices and the current round number.
We output the top candidates for the next round of communication.

The top candidates are selected based on the battery life of the devices.
We want to balance the battery life to ensure devices don't die but we also want to ensure that the high accuracy devices
still contribute to the global model.


"""


def is_candidate(phone, battery, round_num, total_rounds, threshold=0.05):
    # If the battery is below the threshold, the device is not a candidate
    if battery < threshold:
        return False
    # Estimate power and determine if it can be a candidate now or in the future
    try:
        model = phone_models[phone]
    except:
        model = np.random.choice(list(phone_models.values()))
    avg_time = 8.0
    power_consumption = (
        model["baseline_power"]
        + model["cores"] * model["power_coefficient"] * model["frequency"]
    )
    current_wh = battery * model["battery_capacity"]
    if power_consumption * (scaling_factor * (avg_time / 3600)) > current_wh:
        return False
    else:
        return True


# simulating battery life reduction for 100 devices
# show average battery life reduction over 10 communication rounds
# plot the battery life reduction for each device
if __name__ == "__main__":
    import matplotlib.pyplot as plt

    battery = []
    total_energy_per_device = []
    for i in range(100):
        phone, b = init_battery()
        battery.append(b)
        dev_energy = []
        for i in range(50):
            energy = 0
            if is_candidate(phone, b, i, 50) and i not in [0, 48]:
                b, energy = reduce_battery(phone, b, 8.0)
            battery.append(b)
            dev_energy.append(energy)
        total_energy_per_device.append(sum(dev_energy) / 50)
    battery = np.array(battery).reshape(100, 51)
    print("Average energy consumed per device: ", sum(total_energy_per_device) / 100)
    ax = plt.gca()
    ax.set_ylim([0, 1])
    plt.plot(battery.T, alpha=0.5)
    plt.plot(battery.mean(axis=0), color="black")
    plt.xlabel("Communication Round")
    plt.ylabel("Battery Life")
    plt.title("Battery Life Reduction of 100 Devices")
    plt.grid()
    plt.show()
